# 📡 Real-Time Network Traffic Anomaly Detector

A telecommunications engineering mini-project that simulates live network
traffic and uses **unsupervised machine learning (Isolation Forest)** to
detect anomalies such as DDoS floods, port scans, and data-exfiltration-like
patterns — visualized on a live Streamlit dashboard.

## Project Structure
```
network_anomaly_detector/
├── app.py                 # Streamlit dashboard (main app)
├── detector.py             # Isolation Forest anomaly detection model
├── traffic_generator.py    # Simulated normal + attack traffic
├── requirements.txt
└── README.md
```

## How It Works
1. **Training**: the model learns what "normal" traffic looks like
   (packet size, packet rate, port, duration, unique ports contacted).
2. **Live simulation**: a stream generator produces realistic
   packets, occasionally injecting DDoS / port-scan / exfiltration
   patterns.
3. **Detection**: each packet gets an anomaly score; outliers are
   flagged in real time and shown as alerts + highlighted on the chart.

## Run It Locally (free, 5 minutes)
```bash
pip install -r requirements.txt
streamlit run app.py
```
It opens automatically in your browser at `http://localhost:8501`.

---

## How to "List" / Publish This Project for Free

### 1. Put the code on GitHub (do this first — everything else links back to it)
1. Create a free account at https://github.com
2. Create a new repository, e.g. `network-traffic-anomaly-detector`
3. Upload these files (or use git):
   ```bash
   git init
   git add .
   git commit -m "Initial commit: network anomaly detector"
   git branch -M main
   git remote add origin https://github.com/<your-username>/network-traffic-anomaly-detector.git
   git push -u origin main
   ```

### 2. Deploy the live dashboard for free
1. Go to https://share.streamlit.io (Streamlit Community Cloud)
2. Sign in with your GitHub account
3. Click **"New app"** → select your repo → set main file to `app.py`
4. Click **Deploy**. You'll get a public link like:
   `https://network-traffic-anomaly-detector.streamlit.app`
   — this is the link you put on your resume/LinkedIn/portfolio.

### 3. List it on your profile
- **LinkedIn** → Featured section / Projects section: add the GitHub link + live app link + a screenshot or short screen recording.
- **GitHub profile README** → pin this repository so it's the first thing recruiters see.
- **Resume** → one line: *"Built a real-time network traffic anomaly detection system using Isolation Forest and Streamlit; deployed live at [link]."*
- **University portfolio / LMS submission** → attach the GitHub link plus a short PDF report if required (I can generate this too — just ask).

### 4. Optional polish
- Record a 30–60 second demo video (use free screen recorder like OBS Studio) and attach it to the GitHub README and LinkedIn post.
- Add a project banner image to the top of the README.

## Notes on the Data
This version uses a **synthetic traffic generator** so the whole project
runs instantly with zero downloads or setup. For a more advanced version,
you can swap in a real public dataset (e.g. CICIDS2017 or NSL-KDD) or
live packet capture via `pyshark` — same `detector.py` model works either way.
